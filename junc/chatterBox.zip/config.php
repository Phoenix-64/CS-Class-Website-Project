<?php
	$conn = mysqli_connect('localhost' , 'root' , '', 'ajaxdb')or die ('problem to connect database');
?>